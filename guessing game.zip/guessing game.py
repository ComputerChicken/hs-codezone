# vvv I need this vvv
import random
# ^^^ this ^^^

# Generate a random number
num = random.randint(1,100)

# Make guess -1 so that it can't be num
guess = -1
guesses = 0

# Instructions
print("Your goal is to guess a randomly chosen number between 1 and 100, you will be told \"Too low\" or \"Too high\" if you get it wrong.")

# Loop until guess and num are equal
while guess != num:
    guesses += 1
    # Get new guess
    guess = int(input("Make a guess: "))
    # Feedback
    if(guess < num):
        print("Too low")
    elif(guess > num):
        print("Too high")

# The user guesses correctl
print("Correct!")
print(f"It took you {guesses} guesses")